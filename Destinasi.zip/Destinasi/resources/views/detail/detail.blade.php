<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ExploreGK</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- custom css file link  -->
    <link rel="stylesheet" href="{{asset('/home/style.css')}}">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">

    <!-- custom js file link  -->
    <script src="{{asset('js/script.js')}}" defer></script>

    <style type="text/css">
        /*.destination .box-container{
            padding-top: 100px;
        }

        .destination .box-container .box {
            position: relative;
            height: auto;
        }

        .destination .box-container .box .image {
            width: 100%;
            height: 50%;
        }
        
        .destination .box-container .box .image img {
            position: relative;
            display: block;
        }

        .destination .box-container .box .content {
            width: 100%;
            height: auto;
            padding-top: 10px;
        }*/

        .popup-view{
          z-index: 2;
          /*background: rgba(255, 255, 255, 0.5);*/
          position: relative;
          top: 30px;
          right: 0;
          bottom: 0;
          left: 0;
          display: flex;
          justify-content: center;
          align-items: center;
          transition: 0.5s;
      }

      .popup-card{
          position: relative;
          display: flex;
          width: 100%;
          height: 500px;
          margin: 20px;
      }

      .popup-card .product-img{
          z-index: 2;
          background: #1D212B;
          position: relative;
          display: flex;
          justify-content: center;
          align-items: center;
          width: 50%;
          height: 90%;
          transform: translateY(25px);
          border-top-left-radius: 10px;
          border-bottom-left-radius: 10px;
      }

      .popup-card .product-img img{
        z-index: 2;
          position: fixed;
          width: auto;
          /*left: -50px;*/
          border-top-left-radius: 10px;
          border-bottom-left-radius: 10px;
          height: 100%;
      }

      .popup-card .info{
          z-index: 2;
          background: #fff;
          display: flex;
          flex-direction: column;
          width: 55%;
          height: 100%;
          /*box-sizing: border-box;*/
          padding: 40px;
          border-radius: 10px;
      }

      .popup-card .info h2{
          font-size: 20px;
          line-height: 20px;
          margin: 10px;
      }

      .popup-card .info h2 span{
          font-size: 15px;
          text-transform: uppercase;
          letter-spacing: 2px;
      }

      .popup-card .info p{
          font-size: 15px;
          margin: 10px;
      }

      .popup-card .info .price{
          font-size: 45px;
          font-weight: 300;
          margin: 10px;
      }

      .popup-card .info .add-cart-btn{
          color: #fff;
          background: #009DD2;
          font-size: 16px;
          font-weight: 600;
          text-align: center;
          text-decoration: none;
          text-transform: uppercase;
          margin: 10px auto;
          padding: 10px 50px;
          border-radius: 20px;
      }

      .popup-card .info .add-wish{
          color: #009DD2;
          font-size: 16px;
          text-align: center;
          font-weight: 600;
          text-transform: uppercase;
      }

      @media (max-width: 900px){
        .popup-card{
            flex-direction: column;
            width: 100%;
            height: auto;
        }

        .popup-card .product-img{
            z-index: 3;
            width: 100%;
            height: 200px;
            transform: translateY(0);
            border-bottom-left-radius: 0;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }

        .popup-card .product-img img{
            left: initial;
            max-width: 100%;
            border-top-right-radius: 10px;
        }

        .popup-card .info{
            width: 100%;
            height: auto;
            padding: 20px;
            border-top-left-radius: 0;
            border-top-right-radius: 0;
        }

        .popup-card .info h2{
            margin: 20px 5px 5px 5px;
            font-size: 25px;
        }

        .popup-card .info h2 span{
            font-size: 10px;
        }

        .popup-card .info p{
            margin: 5px;
            font-size: 13px;
        }

        .popup-card .info .price{
            margin: 5px;
            font-size: 30px;
        }

        .popup-card .info .add-cart-btn{
            margin: 5px auto;
            padding: 5px 40px;
            font-size: 14px;
        }

        .popup-card .info .add-wish{
            font-size: 14px;
        }

        .popup-card .close-btn{
            z-index: 4;
        }
    }

    </style>

</head>
<body>
    
<!-- header section starts  -->

<header class="header">

    <div id="menu-btn" class="fas fa-bars"></div>

    <a data-aos="zoom-in-left" data-aos-delay="150" href="#" class="logo"> <i class="fas fa-mountain"></i>Explore<span style="color: red;">GK</span> </a>

    <nav class="navbar">
        <a data-aos="zoom-in-left" data-aos-delay="300" href="/">home</a>
        <a data-aos="zoom-in-left" data-aos-delay="450" href="#about">tentang</a>
        <a data-aos="zoom-in-left" data-aos-delay="600" href="#destination">destinasi</a>
        <a data-aos="zoom-in-left" data-aos-delay="750" href="#services">service</a>
        <a data-aos="zoom-in-left" data-aos-delay="900" href="#gallery">galeri</a>
        <a data-aos="zoom-in-left" data-aos-delay="1150" href="#blogs">blogs</a>
    </nav>

    <!-- <a data-aos="zoom-in-left" data-aos-delay="1300" href="#book-form" class="btn">book now</a> -->

</header>

<section class="destination" id="destination">
    
    <!-- <div class="box-container">
        <div class="box" data-aos="fade-up" data-aos-delay="100">
            <div class="image">
                <img src="{{asset('images/'.$detail->gambar)}}" alt="">
            </div>
            <div class="content">
                <h3>{{$detail->destinasi}}</h3>
                <p>{{$detail->deskripsi}}</p>
                <a href="/"><i class="fas fa-angle-left"></i> Back Home</a>
            </div>
        </div>
    </div> -->

     <div class="popup-view">
          <div class="popup-card">
            <div class="product-img">
              <img src="{{asset('images/'.$detail->gambar)}}" alt="">
            </div>
            <div class="info">
              <h2>{{$detail->destinasi}}<br><span>Explore<span style="color:red;">GK</span></span></h2>
              <p>{{$detail->deskripsi}}</p>
              <p><span><b>Lokasi :</b></span>{{$detail->lokasi}}</p>
              <a href="/" class="add-cart-btn">Back To Home</a>
            </div>
          </div>
        </div>
      </div>

</section>

<!-- destination section ends -->

<!-- services section starts  -->

<!-- services section ends -->

<!-- gallery section starts  -->

<!-- gallery section ends -->

<!-- review section starts  -->

<!-- <section class="review">

</section> -->

<!-- review section ends -->

<!-- blogs section starts  -->

<!-- blogs section ends -->

<!-- banner section starts  -->

<div class="banner">

    <div class="content" data-aos="zoom-in-up" data-aos-delay="300">
        <span>Mulai Petualanganmu</span>
        <h3>Mari Kita Eksplore Gunungkidul</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum voluptatum praesentium amet quibusdam quam officia suscipit odio.</p>
        <!-- <a href="#book-form" class="btn">book now</a> -->
    </div>

</div>

<!-- banner section ends -->

<!-- footer section starts  -->

<section class="footer">

    <div class="box-container">

        <div class="box" data-aos="fade-up" data-aos-delay="150">
            <a href="#" class="logo"> <i class="fas fa-mountain"></i>Explore<span style="color:red;">GK</span></a>
            <p>Account Sosial Media?</p>
            <div class="share">
                <a href="#" class="fab fa-tiktok"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-youtube"></a>
            </div>
        </div>

        <div class="box" data-aos="fade-up" data-aos-delay="300">
            <h3>quick links</h3>
            <a href="#home" class="links"> <i class="fas fa-arrow-right"></i> home </a>
            <a href="#about" class="links"> <i class="fas fa-arrow-right"></i> tentang </a>
            <a href="#destination" class="links"> <i class="fas fa-arrow-right"></i> destinasi </a>
            <a href="#services" class="links"> <i class="fas fa-arrow-right"></i> service </a>
            <a href="#gallery" class="links"> <i class="fas fa-arrow-right"></i> galeri </a>
            <a href="#blogs" class="links"> <i class="fas fa-arrow-right"></i> blogs </a>
        </div>

        <div class="box" data-aos="fade-up" data-aos-delay="450">
            <h3>kontak info</h3>
            <p> <i class="fas fa-map"></i> Saptosari, Gunungkidul </p>
            <p> <i class="fas fa-phone"></i> - </p>
            <p> <i class="fas fa-envelope"></i> Nothing@gmail.com </p>
            <!-- <p> <i class="fas fa-clock"></i> 7:00am - 10:00pm </p> -->
        </div>

        <!-- <div class="box" data-aos="fade-up" data-aos-delay="600">
            <h3>newsletter</h3>
            <p>subscribe for latest updates</p>
            <form action="">
                <input type="email" name="" placeholder="enter your email" class="email" id="">
                <input type="submit" value="subscribe" class="btn">
            </form>
        </div> -->

    </div>

</section>

<div class="credit">created by <span>Nothing</span> | Just think & Build what you want!!!</div>

<!-- footer section ends -->



<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
<script>

    AOS.init({
        duration: 800,
        offset:150,
    });

</script>
</body>
</html>