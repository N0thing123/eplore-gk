@extends('template.master')

@section('content')
	Ini Destinasi
@stop