

<?php $__env->startSection('content'); ?>
	Ini Destinasi
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nothing\Desktop\Destinasi\resources\views/destinasi/destinasi.blade.php ENDPATH**/ ?>