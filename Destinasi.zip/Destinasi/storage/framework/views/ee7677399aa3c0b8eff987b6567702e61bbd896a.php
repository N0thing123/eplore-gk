<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ExploreGK</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- custom css file link  -->
    <link rel="stylesheet" href="<?php echo e(asset('/home/style.css')); ?>">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">

    <!-- custom js file link  -->
    <script src="<?php echo e(asset('js/script.js')); ?>" defer></script>

</head>
<body>
    
<!-- header section starts  -->

<header class="header">

    <div id="menu-btn" class="fas fa-bars"></div>

    <a data-aos="zoom-in-left" data-aos-delay="150" href="#" class="logo"> <i class="fas fa-mountain"></i>Explore<span style="color: red;">GK</span> </a>

    <nav class="navbar">
        <a data-aos="zoom-in-left" data-aos-delay="300" href="#home">home</a>
        <a data-aos="zoom-in-left" data-aos-delay="450" href="#about">tentang</a>
        <a data-aos="zoom-in-left" data-aos-delay="600" href="#destination">destinasi</a>
        <a data-aos="zoom-in-left" data-aos-delay="750" href="#services">service</a>
        <a data-aos="zoom-in-left" data-aos-delay="900" href="#gallery">galeri</a>
        <a data-aos="zoom-in-left" data-aos-delay="1150" href="#blogs">blogs</a>
    </nav>

    <!-- <a data-aos="zoom-in-left" data-aos-delay="1300" href="#book-form" class="btn">book now</a> -->

</header>

<!-- header section ends -->

<!-- home section starts  -->

<section class="home" id="home">

    <div class="content">
        <span data-aos="fade-up" data-aos-delay="150">Gunungkidul</span>
        <h3 style="color: black;" data-aos="fade-up" data-aos-delay="300">"ꦒꦸꦤꦸꦁꦏꦶꦢꦸꦭ꧀"</h3>
        <p data-aos="fade-up" data-aos-delay="450">adalah salah satu kabupaten di Daerah Istimewa Yogyakarta, Indonesia. Pusat pemerintahan berada di Kapanewon Wonosari. Nama "Gunungkidul" berasal dari bahasa Jawa (Gunung di Selatan), yang mana wilayahnya terletak di jajaran Pegunungan Kidul Yogyakarta.</p>
        <!-- <a data-aos="fade-up" data-aos-delay="600" href="#" class="btn">book now</a> -->
    </div>

</section>

<!-- home section ends -->

<!-- booking form section starts  -->

<!-- <section class="book-form" id="book-form">

    <form action="">
        <div data-aos="zoom-in" data-aos-delay="150" class="inputBox">
            <span>where to?</span>
            <input type="text" placeholder="place name" value="">
        </div>
        <div data-aos="zoom-in" data-aos-delay="300" class="inputBox">
            <span>when?</span>
            <input type="date" value="">
        </div>
        <div data-aos="zoom-in" data-aos-delay="450" class="inputBox">
            <span>how many?</span>
            <input type="number" placeholder="number of ExploreGKers" value="">
        </div>
        <input data-aos="zoom-in" data-aos-delay="600" type="submit" value="find now" class="btn">
    </form>

</section> -->

<!-- booking form section ends -->

<!-- about section starts  -->

<section class="about" id="about">

    <div class="video-container" data-aos="fade-right" data-aos-delay="300">
        <a href="https://youtu.be/IWWCRBOpLso"><video src="<?php echo e(asset('images/vid-1.mp4')); ?>" muted autoplay loop class="video"></video></a>
        <div class="controls">
            <span class="control-btn" data-src="<?php echo e(asset('images/vid-2.mp4')); ?>"></span>
            <span class="control-btn" data-src="<?php echo e(asset('images/vid-3.mp4')); ?>"></span>
            <span class="control-btn" data-src="<?php echo e(asset('images/vid-4.mp4')); ?>"></span>
        </div>
    </div>

    <div class="content" data-aos="fade-left" data-aos-delay="600">
        <span>Deskripsi</span>
        <h3>Keindahan Alam Menanti Anda</h3>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Unde fugit repellat error deserunt nam aperiam odit libero quos provident. Nostrum?</p>
        <a href="https://youtu.be/IWWCRBOpLso" class="btn">tonton video</a>
    </div>

</section>

<!-- about section ends -->

<!-- destination section starts  -->

<section class="destination" id="destination">

    <div class="heading">
        <span>destinasi kami</span>
        <h1></h1>
    </div>

    <div class="box-container">
        <?php $__currentLoopData = $gambar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="box" data-aos="fade-up" data-aos-delay="150">
            <div class="image">
                <img src="<?php echo e(asset('images/'.$img->gambar)); ?>" alt="">
            </div>
            <div class="content">
                <h3><?php echo e($img->destinasi); ?></h3>
                <p><?php echo e($img->deskripsi); ?></p>
                <a href="/detail/<?php echo e($img->id); ?>">Read More<i class="fas fa-angle-right"></i></a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- <div class="box" data-aos="fade-up" data-aos-delay="300">
            <div class="image">
                <img src="<?php echo e(asset('images/des-2.jpg')); ?>" alt="">
            </div>
            <div class="content">
                <h3>ExploreGK</h3>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing.</p>
                <a href="#">read more <i class="fas fa-angle-right"></i></a>
            </div>
        </div>

        <div class="box" data-aos="fade-up" data-aos-delay="450">
            <div class="image">
                <img src="images/des-3.jpg" alt="">
            </div>
            <div class="content">
                <h3>ExploreGK</h3>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing.</p>
                <a href="#">read more <i class="fas fa-angle-right"></i></a>
            </div>
        </div>

        <div class="box" data-aos="fade-up" data-aos-delay="600">
            <div class="image">
                <img src="images/des-4.jpg" alt="">
            </div>
            <div class="content">
                <h3>ExploreGK</h3>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing.</p>
                <a href="#">read more <i class="fas fa-angle-right"></i></a>
            </div>
        </div>

        <div class="box" data-aos="fade-up" data-aos-delay="750">
            <div class="image">
                <img src="images/des-5.jpg" alt="">
            </div>
            <div class="content">
                <h3>ExploreGK</h3>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing.</p>
                <a href="#">read more <i class="fas fa-angle-right"></i></a>
            </div>
        </div>

        <div class="box" data-aos="fade-up" data-aos-delay="900">
            <div class="image">
                <img src="images/des-6.jpg" alt="">
            </div>
            <div class="content">
                <h3>ExploreGK</h3>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing.</p>
                <a href="#">read more <i class="fas fa-angle-right"></i></a>
            </div>
        </div>

        <div class="box" data-aos="fade-up" data-aos-delay="1150">
            <div class="image">
                <img src="images/des-7.jpg" alt="">
            </div>
            <div class="content">
                <h3>ExploreGK</h3>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing.</p>
                <a href="#">read more <i class="fas fa-angle-right"></i></a>
            </div>
        </div>

        <div class="box" data-aos="fade-up" data-aos-delay="1300">
            <div class="image">
                <img src="images/des-8.jpg" alt="">
            </div>
            <div class="content">
                <h3>ExploreGK</h3>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing.</p>
                <a href="#">read more <i class="fas fa-angle-right"></i></a>
            </div>
        </div> -->

    </div>

</section>

<!-- destination section ends -->

<!-- services section starts  -->

<section class="services" id="services">

    <div class="heading">
        <span>our services</span>
        <h1>countless expericences</h1>
    </div>

    <div class="box-container">

        <div class="box" data-aos="zoom-in-up" data-aos-delay="150">
            <i class="fas fa-globe"></i>
            <h3>worldwide</h3>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Numquam, cumque.</p>
        </div>

        <div class="box" data-aos="zoom-in-up" data-aos-delay="300">
            <i class="fas fa-hiking"></i>
            <h3>adventures</h3>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Numquam, cumque.</p>
        </div>

        <div class="box" data-aos="zoom-in-up" data-aos-delay="450">
            <i class="fas fa-utensils"></i>
            <h3>food & drinks</h3>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Numquam, cumque.</p>
        </div>

        <div class="box" data-aos="zoom-in-up" data-aos-delay="600">
            <i class="fas fa-hotel"></i>
            <h3>affordable hotels</h3>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Numquam, cumque.</p>
        </div>

        <div class="box" data-aos="zoom-in-up" data-aos-delay="750">
            <i class="fas fa-wallet"></i>
            <h3>affordable price</h3>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Numquam, cumque.</p>
        </div>

        <div class="box" data-aos="zoom-in-up" data-aos-delay="900">
            <i class="fas fa-headset"></i>
            <h3>24/7 support</h3>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Numquam, cumque.</p>
        </div>

    </div>

</section>

<!-- services section ends -->

<!-- gallery section starts  -->

<section class="gallery" id="gallery">

    <div class="heading">
        <span>Galeri</span>
        <h1>spot</h1>
    </div>
    
    <div class="box-container">
        <?php $__currentLoopData = $spot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="box" data-aos="zoom-in-up" data-aos-delay="150">
            <img src="<?php echo e(asset('img/'.$sp->spot)); ?>" alt="">
            <span>Gunungkidul spot</span>
            <h3><?php echo e($sp->tempat); ?></h3>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- <div class="box" data-aos="zoom-in-up" data-aos-delay="300">
            <img src="images/gallery-img-2.jpg" alt="">
            <span>Gunungkidul spot</span>
            <h3>greenland</h3>
        </div>

        <div class="box" data-aos="zoom-in-up" data-aos-delay="450">
            <img src="images/gallery-img-3.jpg" alt="">
            <span>Gunungkidul spot</span>
            <h3>alaska</h3>
        </div>

        <div class="box" data-aos="zoom-in-up" data-aos-delay="150">
            <img src="images/gallery-img-4.jpg" alt="">
            <span>Gunungkidul spot</span>
            <h3>thailand</h3>
        </div>

        <div class="box" data-aos="zoom-in-up" data-aos-delay="300">
            <img src="images/gallery-img-5.jpg" alt="">
            <span>Gunungkidul spot</span>
            <h3>brazil</h3>
        </div>

        <div class="box" data-aos="zoom-in-up" data-aos-delay="450">
            <img src="images/gallery-img-6.jpg" alt="">
            <span>Gunungkidul spot</span>
            <h3>maldive</h3>
        </div>

        <div class="box" data-aos="zoom-in-up" data-aos-delay="150">
            <img src="images/gallery-img-7.jpg" alt="">
            <span>Gunungkidul spot</span>
            <h3>iceland</h3>
        </div>

        <div class="box" data-aos="zoom-in-up" data-aos-delay="300">
            <img src="images/gallery-img-8.jpg" alt="">
            <span>Gunungkidul spot</span>
            <h3>alaska</h3>
        </div>

        <div class="box" data-aos="zoom-in-up" data-aos-delay="450">
            <img src="images/gallery-img-9.jpg" alt="">
            <span>Gunungkidul spot</span>
            <h3>maldive</h3>
        </div> -->

    </div>

</section>

<!-- gallery section ends -->

<!-- review section starts  -->

<!-- <section class="review">

    <div class="content" data-aos="fade-right" data-aos-delay="300">
        <span>Pengalaman</span>
        <h3>pengalaman dari para pengunjung</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Assumenda laudantium corporis fugiat quae unde perspiciatis similique ab modi enim consequatur aperiam cumque distinctio facilis sit, debitis possimus asperiores non harum.</p>
    </div>

    <div class="box-container" data-aos="fade-left" data-aos-delay="600">

        <div class="box">
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quia, ratione.</p>
            <div class="user">
                <img src="images/pic-1.png" alt="">
                <div class="info">
                    <h3>john deo</h3>
                    <span>designer</span>
                </div>
            </div>
        </div>
        <div class="box">
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quia, ratione.</p>
            <div class="user">
                <img src="images/pic-2.png" alt="">
                <div class="info">
                    <h3>john deo</h3>
                    <span>designer</span>
                </div>
            </div>
        </div>
        <div class="box">
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quia, ratione.</p>
            <div class="user">
                <img src="images/pic-3.png" alt="">
                <div class="info">
                    <h3>john deo</h3>
                    <span>designer</span>
                </div>
            </div>
        </div>
        <div class="box">
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quia, ratione.</p>
            <div class="user">
                <img src="images/pic-4.png" alt="">
                <div class="info">
                    <h3>john deo</h3>
                    <span>designer</span>
                </div>
            </div>
        </div>

    </div>

</section> -->

<!-- review section ends -->


<!-- blogs section starts  -->


<section class="blogs" id="blogs">

    <div class="heading">
        <span>blogs & posts</span>
        <h1>we untold stories</h1>
    </div>

    <div class="box-container">
        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="box" data-aos="fade-up" data-aos-delay="150">
            <div class="image">
                <img src="<?php echo e(asset('post/'.$p->foto)); ?>" alt="">
            </div>
            <div class="content">
                <a href="#" class="link"><?php echo e($p->judul); ?></a>
                <p><?php echo e($p->desk); ?></p>
                <div class="icon">
                    <a href="#"><i class="fas fa-clock"></i> <?php echo e($p->tgl); ?></a>
                    <a href="#"><i class="fas fa-user"></i> by <?php echo e($p->pengirim); ?></a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- <div class="box" data-aos="fade-up" data-aos-delay="300">
            <div class="image">
                <img src="images/blog-2.jpg" alt="">
            </div>
            <div class="content">
                <a href="#" class="link">Life is a journey, not a destination</a>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, natus!</p>
                <div class="icon">
                    <a href="#"><i class="fas fa-clock"></i> 21st may, 2021</a>
                    <a href="#"><i class="fas fa-user"></i> by admin</a>
                </div>
            </div>
        </div>

        <div class="box" data-aos="fade-up" data-aos-delay="450">
            <div class="image">
                <img src="images/blog-3.jpg" alt="">
            </div>
            <div class="content">
                <a href="#" class="link">Life is a journey, not a destination</a>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, natus!</p>
                <div class="icon">
                    <a href="#"><i class="fas fa-clock"></i> 21st may, 2021</a>
                    <a href="#"><i class="fas fa-user"></i> by admin</a>
                </div>
            </div>
        </div> -->
    </div>
</section>

<section class="book-form" id="book-form">
    <h1 style="color: ghostwhite; font-size: 20px; text-align: center;" data-aos="zoom-in" data-aos-delay="150">Ceritakan Pengalaman Anda</h1><br><br>

    <form action="/kirim" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div data-aos="zoom-in" data-aos-delay="150" class="inputBox">
            <span>Nama Pengirim</span>
            <input type="text" name="pengirim" required="">
        </div>
        <div data-aos="zoom-in" data-aos-delay="150" class="inputBox">
            <span>Judul</span>
            <input type="text" name="judul" required="">
        </div>
        <div data-aos="zoom-in" data-aos-delay="150" class="inputBox">
            <span>Deskripsi</span>
            <textarea type="text" name="desk" required=""></textarea>
        </div>
        <div data-aos="zoom-in" data-aos-delay="250" class="inputBox">
            <span>Tanggal</span>
            <input type="date" name="tgl" required="">
        </div>
        <div data-aos="zoom-in" data-aos-delay="350" class="inputBox">
            <span>Foto</span>
            <input type="file" name="foto" required="">
        </div>
        <input data-aos="zoom-in" data-aos-delay="450" type="submit" class="btn">
    </form>

</section>

<!-- blogs section ends -->

<!-- banner section starts  -->

<div class="banner">

    <div class="content" data-aos="zoom-in-up" data-aos-delay="300">
        <span>Mulai Petualanganmu</span>
        <h3>Mari Kita Eksplore Gunungkidul</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum voluptatum praesentium amet quibusdam quam officia suscipit odio.</p>
        <!-- <a href="#book-form" class="btn">book now</a> -->
    </div>

</div>

<!-- banner section ends -->

<!-- footer section starts  -->

<section class="footer">

    <div class="box-container">

        <div class="box" data-aos="fade-up" data-aos-delay="150">
            <a href="#" class="logo"> <i class="fas fa-mountain"></i>Explore<span style="color:red;">GK</span></a>
            <p>Account Sosial Media?</p>
            <div class="share">
                <a href="#" class="fab fa-tiktok"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-instagram"></a>
                <a href="#" class="fab fa-youtube"></a>
            </div>
        </div>

        <div class="box" data-aos="fade-up" data-aos-delay="300">
            <h3>quick links</h3>
            <a href="#home" class="links"> <i class="fas fa-arrow-right"></i> home </a>
            <a href="#about" class="links"> <i class="fas fa-arrow-right"></i> tentang </a>
            <a href="#destination" class="links"> <i class="fas fa-arrow-right"></i> destinasi </a>
            <a href="#services" class="links"> <i class="fas fa-arrow-right"></i> service </a>
            <a href="#gallery" class="links"> <i class="fas fa-arrow-right"></i> galeri </a>
            <a href="#blogs" class="links"> <i class="fas fa-arrow-right"></i> blogs </a>
        </div>

        <div class="box" data-aos="fade-up" data-aos-delay="450">
            <h3>kontak info</h3>
            <p> <i class="fas fa-map"></i> Saptosari, Gunungkidul </p>
            <p> <i class="fas fa-phone"></i> - </p>
            <p> <i class="fas fa-envelope"></i> Nothing@gmail.com </p>
            <!-- <p> <i class="fas fa-clock"></i> 7:00am - 10:00pm </p> -->
        </div>

        <!-- <div class="box" data-aos="fade-up" data-aos-delay="600">
            <h3>newsletter</h3>
            <p>subscribe for latest updates</p>
            <form action="">
                <input type="email" name="" placeholder="enter your email" class="email" id="">
                <input type="submit" value="subscribe" class="btn">
            </form>
        </div> -->

    </div>

</section>

<div class="credit">created by <span>Nothing</span> | Just think & Build what you want!!!</div>

<!-- footer section ends -->



<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
<script>

    AOS.init({
        duration: 800,
        offset:150,
    });

</script>
</body>
</html><?php /**PATH C:\Users\Nothing\Desktop\Destinasi\resources\views/home.blade.php ENDPATH**/ ?>