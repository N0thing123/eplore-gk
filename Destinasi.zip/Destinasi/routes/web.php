<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DestinasiController;
use App\Http\Controllers\PostController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('home');
// });
Route::get('/',[DestinasiController::class,'destinasi'])->name('destinasi');

Route::get('/destinasi',[DestinasiController::class,'index'])->name('index');
Route::get('/spot',[DestinasiController::class,'spot'])->name('spot');
Route::post('/kirim',[DestinasiController::class,'send'])->name('send');
Route::get('/home',[DestinasiController::class,'desti'])->name('desti');
Route::post('/upload',[DestinasiController::class,'kirim'])->name('kirim');
Route::get('/detail/{id}',[DestinasiController::class,'detail'])->name('detail');

Route::post('/kirim',[PostController::class,'post'])->name('post');