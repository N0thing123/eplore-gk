<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\destinasi;
use App\Models\spot;
use App\Models\Post;


class DestinasiController extends Controller
{
    public function destinasi(){
        $spot = spot::all();
        $gambar = destinasi::all();
        $post = Post::all();
        return view('home',['gambar'=>$gambar, 'spot'=>$spot, 'post'=>$post]);
    }

    public function index(){
        return view('landing.landing');
    }

    public function desti(){
        return view('destinasi.destinasi');
    }

    public function kirim(Request $request){
        // dd($request->all());
        $nm = $request->gambar;
        $namaFile = time().rand(100,999).".".$nm->getClientOriginalName();
        $nm->move(public_path().'/images', $namaFile);
        $nama = $request->destinasi;
        $lokasi = $request->lokasi;
        $desk = $request->deskripsi;

        destinasi::insert([
            'destinasi' => $nama,
            'deskripsi' => $desk,
            'lokasi' => $lokasi,
            'gambar' => $namaFile,
        ]);
        return redirect('/destinasi');
    }

    public function spot(){
        return view('spot.spot');
    }

    public function send(Request $request) {
        // dd($request->all());
        $nm = $request->spot;
        $image = time().rand(100,999).".".$nm->getClientOriginalName();
        $nm->move(public_path().'/img', $image);

        spot::insert([
            'tempat' => $request->tempat,
            'spot' => $image,
        ]);
        return redirect('/spot');
    }

    public function detail($id) {
        $detail = destinasi::findOrFail($id);
        return view('detail.detail',['detail'=>$detail]);
    }
}
