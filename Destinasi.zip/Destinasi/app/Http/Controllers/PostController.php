<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use DB;

class PostController extends Controller
{
    public function post(Request $request){
        // dd($request->all());
        $nm = $request->foto;
        $namaFile = time().rand(100,999).".".$nm->getClientOriginalName();
        $nm->move(public_path().'/post', $namaFile);


        DB::table('posts')->insert([
            'pengirim' => $request->pengirim,
            'judul' => $request->judul,
            'desk' => $request->desk,
            'tgl' => $request->tgl,
            'foto' => $namaFile,
        ]);

        return redirect('/');
    }
}
