<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class spot extends Model
{
    protected $table = 'spot';
    protected $fillable = ['tempat','spot'];
}
